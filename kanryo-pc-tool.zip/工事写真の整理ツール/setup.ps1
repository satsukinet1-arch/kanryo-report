﻿# 工事写真の整理ツール　はじめの設定（1回だけ）
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
try {
    $Root = 'C:\工事写真'
    $ToolDir = Join-Path $Root '整理ツール'
    if (-not (Test-Path -LiteralPath $ToolDir)) { New-Item -ItemType Directory -Path $ToolDir -Force | Out-Null }

    # ツール本体をコピー
    $src = Join-Path $PSScriptRoot 'organize.ps1'
    $dst = Join-Path $ToolDir 'organize.ps1'
    Copy-Item -LiteralPath $src -Destination $dst -Force
    Unblock-File -LiteralPath $dst -ErrorAction SilentlyContinue

    # デスクトップにボタン（ショートカット）を作る
    $desk = [Environment]::GetFolderPath('Desktop')
    $lnk = Join-Path $desk '工事写真を整理する.lnk'
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($lnk)
    $sc.TargetPath = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $sc.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $dst + '"'
    $sc.WorkingDirectory = $ToolDir
    $sc.IconLocation = (Join-Path $env:WINDIR 'System32\shell32.dll') + ',3'
    $sc.Description = 'スマホから書き出した工事写真を、C:\工事写真 に整理します'
    $sc.Save()

    [System.Windows.Forms.MessageBox]::Show(
        "設定が終わりました。`n`nデスクトップに「工事写真を整理する」ができました。`n写真は「C:\工事写真」にまとまります。`n`nこのフォルダとダウンロードしたZIPは、もう消してもかまいません。",
        '工事写真の整理ツール') | Out-Null
    Start-Process explorer.exe $Root
} catch {
    [System.Windows.Forms.MessageBox]::Show(
        "うまく設定できませんでした。`nこの画面の写真を撮って、たいきに送ってください。`n`n" + $_.Exception.Message,
        '工事写真の整理ツール') | Out-Null
}
