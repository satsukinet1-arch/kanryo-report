﻿# 工事写真を整理する（工事完了報告書メーカー用）
# ダウンロード／Googleドライブにある書き出しZIPを開いて、
#   C:\工事写真\<物件名>\<施工日>_<工事件名>\
# に自動で振り分けます。

# ===== 設定（必要なら変更してください） =====
$Root = 'C:\工事写真'
# ===========================================

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.Windows.Forms

function Safe-Name([string]$s, [string]$fallback) {
    if ($null -eq $s) { $s = '' }
    $s = ($s -replace '[\\/:\*\?"<>\|\r\n\t]', '').Trim().TrimEnd('.')
    $s = $s -replace '\s+', ' '
    if ($s.Length -gt 60) { $s = $s.Substring(0, 60) }
    if ($s -eq '') { return $fallback }
    return $s
}

# フォルダの中身を、同じ名前のフォルダに重ねてコピーする
function Copy-Merge([string]$from, [string]$to) {
    if (-not (Test-Path -LiteralPath $to)) { New-Item -ItemType Directory -Path $to -Force | Out-Null }
    foreach ($item in Get-ChildItem -LiteralPath $from -Force) {
        $target = Join-Path $to $item.Name
        if ($item.PSIsContainer) { Copy-Merge $item.FullName $target }
        else {
            if (Test-Path -LiteralPath $target) { (Get-Item -LiteralPath $target -Force).Attributes = 'Normal' }
            Copy-Item -LiteralPath $item.FullName -Destination $target -Force
        }
    }
}

# --- ZIPを探す場所 ---
$sources = New-Object System.Collections.Generic.List[string]
$dl = Join-Path $env:USERPROFILE 'Downloads'
if (Test-Path $dl) { $sources.Add($dl) }
foreach ($drv in [System.IO.DriveInfo]::GetDrives()) {
    if (-not $drv.IsReady) { continue }
    foreach ($sub in @('マイドライブ\工事報告書', 'My Drive\工事報告書', 'マイドライブ', 'My Drive')) {
        $p = Join-Path $drv.RootDirectory.FullName $sub
        if ((Test-Path $p) -and -not $sources.Contains($p)) { $sources.Add($p) }
    }
}

# --- 案件データ.json が入っているZIPだけを対象にする ---
$zips = @()
foreach ($src in $sources) {
    foreach ($z in Get-ChildItem -LiteralPath $src -Filter '*.zip' -File -ErrorAction SilentlyContinue) {
        try {
            $za = [System.IO.Compression.ZipFile]::OpenRead($z.FullName)
            $ok = $false
            foreach ($e in $za.Entries) { if ($e.FullName -like '*案件データ.json') { $ok = $true; break } }
            $za.Dispose()
            if ($ok) { $zips += $z }
        } catch { }
    }
}

if ($zips.Count -eq 0) {
    [System.Windows.Forms.MessageBox]::Show(
        "整理するZIPが見つかりませんでした。`n`n探した場所：`n" + ($sources -join "`n") +
        "`n`nスマホで「PCへ書き出し」をして、ZIPをダウンロードかGoogleドライブに入れてから、もう一度ダブルクリックしてください。",
        '工事写真の整理') | Out-Null
    exit
}

if (-not (Test-Path -LiteralPath $Root)) { New-Item -ItemType Directory -Path $Root | Out-Null }
$done = New-Object System.Collections.Generic.List[string]
$errors = New-Object System.Collections.Generic.List[string]

foreach ($z in $zips) {
    $tmp = Join-Path $env:TEMP ('kanryo_' + [guid]::NewGuid().ToString('N'))
    try {
        [System.IO.Compression.ZipFile]::ExtractToDirectory($z.FullName, $tmp)
        $jsons = Get-ChildItem -LiteralPath $tmp -Recurse -File -Filter '案件データ.json'
        foreach ($j in $jsons) {
            $caseDir = $j.Directory.FullName
            $data = Get-Content -LiteralPath $j.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            $prop  = Safe-Name $data.f.prop '物件名なし'
            $title = Safe-Name $data.f.title '工事'
            $date  = Safe-Name $data.f.d1 ''
            if ($date -eq '') { $date = $z.LastWriteTime.ToString('yyyy-MM-dd') }

            $propDir = Join-Path $Root $prop
            $dest = Join-Path $propDir ($date + '_' + $title)
            if (-not (Test-Path -LiteralPath $dest)) { New-Item -ItemType Directory -Path $dest -Force | Out-Null }

            # 中身をコピー（同じ案件をもう一度書き出したときは上書き）
            Copy-Merge $caseDir $dest
            # 戻すとき用のデータは見えにくくしておく
            $jf = Join-Path $dest '案件データ.json'
            if (Test-Path -LiteralPath $jf) { (Get-Item -LiteralPath $jf -Force).Attributes = 'Hidden' }

            $done.Add($prop + '\' + $date + '_' + $title)
        }

        # 済んだZIPは「取り込み済み」フォルダへ
        $doneDir = Join-Path $z.DirectoryName '取り込み済み'
        if (-not (Test-Path -LiteralPath $doneDir)) { New-Item -ItemType Directory -Path $doneDir | Out-Null }
        $to = Join-Path $doneDir $z.Name
        if (Test-Path -LiteralPath $to) { $to = Join-Path $doneDir ($z.BaseName + '_' + (Get-Date -Format 'HHmmss') + '.zip') }
        Move-Item -LiteralPath $z.FullName -Destination $to
    } catch {
        $errors.Add($z.Name + '：' + $_.Exception.Message)
    } finally {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

$msg = "$($done.Count)件の工事を「$Root」に整理しました。`n`n" + (($done | Select-Object -First 15) -join "`n")
if ($done.Count -gt 15) { $msg += "`n…ほか$($done.Count - 15)件" }
if ($errors.Count -gt 0) { $msg += "`n`nうまくいかなかったもの：`n" + ($errors -join "`n") }
$msg += "`n`n使い終わったZIPは「取り込み済み」フォルダに移しました。"
[System.Windows.Forms.MessageBox]::Show($msg, '工事写真の整理') | Out-Null
Start-Process explorer.exe $Root
